# Driver SHT3xD for ESP32 and ESP-IDF framework

Sensor driver SHT40, SHT41, SHT45 for ESP32-based devices running FreeRTOS