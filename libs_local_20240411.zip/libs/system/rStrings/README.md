# rStrings

Simple library for dynamically generating strings based on templates (format and time).
