#pragma once
#include "project_config.h"

#define CONFIG_BEEP_STATIC_ALLOCATION 1
#define CONFIG_BEEP_QUEUE_SIZE 3
#define CONFIG_BEEP_QUEUE_WAIT 10
#define CONFIG_BEEP_TASK_STACK_SIZE 1024


